<?php
/*******************************************************************************
*  Title: Help Desk Software HESK
*  Version: 2.2 from 9th June 2010
*  Author: Klemen Stirn
*  Website: http://www.hesk.com
********************************************************************************
*  COPYRIGHT AND TRADEMARK NOTICE
*  Copyright 2005-2010 Klemen Stirn. All Rights Reserved.
*  HESK is a registered trademark of Klemen Stirn.

*  The HESK may be used and modified free of charge by anyone
*  AS LONG AS COPYRIGHT NOTICES AND ALL THE COMMENTS REMAIN INTACT.
*  By using this code you agree to indemnify Klemen Stirn from any
*  liability that might arise from it's use.

*  Selling the code for this program, in part or full, without prior
*  written consent is expressly forbidden.

*  Using this code, in part or full, to create derivate work,
*  new scripts or products is expressly forbidden. Obtain permission
*  before redistributing this software over the Internet or in
*  any other medium. In all cases copyright and header must remain intact.
*  This Copyright is in full effect in any country that has International
*  Trade Agreements with the United States of America or
*  with the European Union.

*  Removing any of the copyright notices without purchasing a license
*  is expressly forbidden. To remove HESK copyright notice you must purchase
*  a license for this script. For more information on how to obtain
*  a license please visit the page below:
*  https://www.hesk.com/buy.php
*******************************************************************************/

/* Check if this is a valid include */
if (!defined('IN_SCRIPT')) {die('Invalid attempt');}

eval(gzinflate(base64_decode('DdBHkqNIAADA50x3cBBGuNjYA7aEd6Iwlw1B4YS3Erx+5wmZxf
HqfqqrGcrutRU/2WstmPt/qMhHVPz8kZGstrPtCYrsX/SwJ6PC63IMm6/Q7s7WN2OudIxcM0wRI6rb11
eJCGyfa1Y3CUwzp3YTK4qn24SguTIapMmD1Jyw2UdFpKrsSonz3U16NCGaxuhTJukCngtJyQ9PwtM7dH
xksU/8zI7cCoV07LXgQG0qCIhw1JlyzysUMfpO1iuTPMtsvVx6y4Knp3NFeQEThJkN4DdmELV3WxAxRH
KT3xOf7oGpvVpSPPPtOJfX2iO2CGERYLJcz9FJyJhmueS6UJrvnL2ZMbW7t4EbSyeY10wXM20/D9JK4e
RK9d7b9vftUDo0rA+Mje3VRsVHcSr63coi8rdNzYm3Ljd4a0uh6Lr9rogBlCCn5H8j7cpz2HSgHxrQ9J
vUd3o84slj6r/jy4/eRDyuyVDmo7QHY+eBqu/kv0zVAOWydKYdwBzb8y9wj2YSwCZVrkQ/+WXUYiI++1
3k2Qa7is18FCn3HorZwskosPz9FNE6D1wAPDlj77kw0XJipn4Te7jvgmreQjIUKvbM7pzuGYRgAc7gsI
0Sp5BC3xw/iMs1lOQKQgVD5XnrmzOsE9UuVVwOmr0DTYrLUw55bWSbl/3CZ94cs+nuM5V1DD7mgjcpn9
1EaWhKteqcpggkpN+mi9MYaKlDteJ8oK6KcbEI4lq+jVcc3BuVCdOcXAeKeJpxjxm2AHff1KKV+zA41Z
3fkFGsPWkQXEPryZuhyClFbWSkUxV3VXf5tswiA6qsyefx8WDBENhIab/TZUKWx/0PTj/F6ioBeqw62T
p6LT2zfEW2muicHoOApqWLzNi6AxRkC70RYhW++8+y1oxy2gC3CXDzMlgy9jbc0+BTUAez61nvDY+5jU
yNeLCcYMNZy5MewSUD7CODOBfu09Q4u3m2SV+AIirNmnX9XS85Rqr52+Fe9O1gMex2+yj//vn9/f3nfw
==')));

exit();
?>
